<?php
$cms_version = '1.0.0';

$cms_db_version = 20210927;

$cms_required_php_version = '5.6.20';

$cms_required_mysql_version = '5.0';
