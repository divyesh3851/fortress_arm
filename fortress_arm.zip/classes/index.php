<?php
header('HTTP/1.0 403 Forbidden', true, 403);
?>
<!DOCTYPE html>
<html>
	<head>
	<title>403 Forbidden</title>
</head>
<body>
	<h1>Forbidden</h1>
	<p>You don't have permission to access / on this server.<br></p>
</body>
</html>